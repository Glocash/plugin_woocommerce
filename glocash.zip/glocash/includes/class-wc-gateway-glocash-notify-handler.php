<?php

if ( ! defined( "ABSPATH" ) ) {
	exit; // Exit if accessed directly
}

include_once( "class-wc-gateway-glocash-response.php" );

/**
 * Handles responses from Glocash Notify
 */
class WC_Gateway_Glocash_Notify_Handler extends WC_Gateway_Glocash_Response {

	/**
	 * Constructor
	 */
	public function __construct( $sandbox = false) {
		add_action( "woocommerce_api_wc_gateway_glocash", array( $this, "check_response" ) );
		add_action( "valid-glocash-notify", array( $this, "valid_response" ) );

		$this->sandbox        = $sandbox;
	}

	/**
	 * Check for Glocash Notify Response
	 */
	public function check_response() {
		if ( ! empty( $_POST ) && $this->validate_notify() ) {
			$posted = wp_unslash( $_POST );

			do_action( "valid-glocash-notify", $posted );
			exit;
		}

		wp_die( "Glocash Notify failed", "Glocash Notify", array( "response" => 400 ) );
	}

	/**
	 * There was a valid response
	 * @param  array $posted Post data after wp_unslash
	 */
	public function valid_response( $posted ) {
			if ( ! empty( $posted["REQ_INVOICE"] ) && ( $order = $this->get_glocash_order($posted["REQ_INVOICE"], $posted["REQ_INVOICE"]) ) ) {

// 			// Lowercase returned variables
// 			$posted['payment_status'] = strtolower( $posted['payment_status'] );

// 			// Sandbox fix
// 			if ( isset( $posted['test_Notify'] ) && 1 == $posted['test_Notify'] && 'pending' == $posted['payment_status'] ) {
// 				$posted['payment_status'] = 'completed';
// 			}

			if (!$this->isGlocash($order->payment_method)) {
				if ($posted["BIL_STATUS"] != "completed") {
					die ("payment method changed");
				}
			}
			
			WC_Gateway_Glocash::log( "Found order #" . $order->id );
			WC_Gateway_Glocash::log( "Payment status: " . $posted["BIL_STATUS"] );

			if ( method_exists( __CLASS__, "payment_status_" . $posted["BIL_STATUS"] ) ) {
				call_user_func( array( __CLASS__, "payment_status_" . $posted["BIL_STATUS"] ), $order, $posted );
				die ("OK");
			}
		} else {
			die ("order not found ");
		}
	}
	
	protected function isGlocash($payment_method) {
		return substr($payment_method, 0, strlen("glocash")) === "glocash";
	}

	/**
	 *   
	 * Check Glocash notify validity
	 */
	public function validate_notify() {
		WC_Gateway_Glocash::log( "Checking Notify response is valid" );
		$glocash = new WC_Gateway_Glocash();
		$apiKey = $glocash->get_option("api_key");
		$secretKey = $glocash->get_option("secret_key");
		
		$check_array = array(
				"apiKey"=>$apiKey,
				"secretKey"=>$secretKey
		);
		WC_Gateway_Glocash::log( "notify: " .json_encode($_POST) );
		$valid = $this->validatePSNSIGN($_POST,$check_array);
		
		if($valid){
			WC_Gateway_Glocash::log( "Received valid response from Glocash" );
			return true;
		} else {
			WC_Gateway_Glocash::log( "Received invalid response from Glocash" );
		}
		
		return false;
	}
	
	// 验证 付款结果/PSN 提交的REQ_SIGN 是否合法
	public function validatePSNSIGN($param,$check_array){
		// REQ_SIGN = SHA256 ( SECRET_KEY + REQ_TIMES + REQ_EMAIL + CUS_EMAIL + TNS_GCID + BIL_STATUS + BIL_METHOD + PGW_PRICE + PGW_CURRENCY )
		$sign = hash("sha256",
				$check_array["secretKey"].
				$param['REQ_TIMES'].
				$check_array["apiKey"].
				$param["CUS_EMAIL"].
				$param["TNS_GCID"].
				$param["BIL_STATUS"].
				$param["BIL_METHOD"].
				$param["PGW_PRICE"].
				$param["PGW_CURRENCY"]
		);

		return $sign==$param['REQ_SIGN'];
	}
	
	private function validate_amount_currency( $order, $posted ) {
		// Validate currency
		$order_amount = number_format( $order->get_total(), 2, ".", "" );
		$order_currency = $order->get_order_currency();
		$currency = $posted["BIL_CURRENCY"];
		$amount = $posted["BIL_PRICE"];
		$error = false;
		$error_amount = null;
		$error_currency = null;
		WC_Gateway_Glocash::log( "validate_amount_currency：" . json_encode($posted) . " ===".$currency."-".$amount );
		if ($order_currency == $currency) {
			if ($order_amount != $amount) {
				$error = 1;
				$error_amount = $amount;
			}
		}
		
		if (1 == $error) {
			WC_Gateway_Glocash::log( "Payment error: Amounts do not match (gross " . $error_amount . ")" );
			
			// Put this order on-hold for manual checking
			$order->update_status( "on-hold", sprintf( __( "Validation error: Glocash amounts do not match (gross %s).", "woocommerce" ), $error_amount ) );
			exit;
		} else if (2 == $error) {
			WC_Gateway_Glocash::log( "Payment error: Currencies do not match (sent \"" . $order->get_order_currency() . "\" | returned \"" . $error_currency . "\")" );
			
			// Put this order on-hold for manual checking
			$order->update_status( "on-hold", sprintf( __( "Validation error: Glocash currencies do not match (code %s).", "woocommerce" ), $error_currency ) );
			exit;
		}
	}

	/**
	 * Check currency from Notify matches the order
	 * @param  WC_Order $order
	 * @param  string $currency
	 */
	private function validate_currency( $order, $currency ) {
		// Validate currency
		if ( $order->get_order_currency() != $currency ) {
			WC_Gateway_Glocash::log( "Payment error: Currencies do not match (sent \"" . $order->get_order_currency() . "\" | returned \"" . $currency . "\")" );

			// Put this order on-hold for manual checking
			$order->update_status( "on-hold", sprintf( __( "Validation error: Glocash currencies do not match (code %s).", "woocommerce" ), $currency ) );
			exit;
		}
	}

	/**
	 * Check payment amount from Notify matches the order
	 * @param  WC_Order $order
	 */
	private function validate_amount( $order, $amount ) {
		if ( number_format( $order->get_total(), 2, ".", "" ) != number_format( $amount, 2, ".", "" ) ) {
			WC_Gateway_Glocash::log( "Payment error: Amounts do not match (gross " . $amount . ")" );

			// Put this order on-hold for manual checking
			$order->update_status( "on-hold", sprintf( __( "Validation error: Glocash amounts do not match (gross %s).", "woocommerce" ), $amount ) );
			exit;
		}
	}

	/**
	 * 
		"wc-pending"   
		"wc-processing
		"wc-on-hold"   
		"wc-completed
		"wc-cancelled" 
		"wc-refunded" 
		"wc-failed"
	 */
	
	/**
	 * Handle a unpaid payment
	 * @param  WC_Order $order
	 */
	private function payment_status_unpaid( $order, $posted ) {
		$order->update_status( "pending", sprintf( __( "Payment %s via Glocash Notify.", "woocommerce" ), wc_clean( $posted["BIL_STATUS"] ) ) );
	}
	
	/**
	 * Handle a completed payment
	 * @param  WC_Order $order
	 */
	private function payment_status_paid( $order, $posted ) {
		if ( $order->has_status( "completed" ) ) {
			WC_Gateway_Glocash::log( "Aborting, Order #" . $order->id . " is already complete." );
			exit;
		}
		
		$this->validate_amount_currency( $order, $posted );
		//$this->validate_currency( $order, $posted["currency"] );
		//$this->validate_amount( $order, $posted["amount"] );
		
		if ( "paid" === $posted["BIL_STATUS"] ) {
			$this->payment_complete( $order,"", __( "Glocash Notify payment completed", "woocommerce" ) );
		} else {
			$this->payment_on_hold( $order, sprintf( __( "Payment pending", "woocommerce" )) );
		}
	}
	
	/**
	 * Handle a pending payment
	 * @param  WC_Order $order
	 */
	private function payment_status_pending( $order, $posted ) {
		if ( $order->has_status( "completed" ) ) {
			WC_Gateway_Glocash::log( "Aborting, Order #" . $order->id . " is already complete." );
			exit;
		}
		
		$this->validate_amount_currency( $order, $posted );
		
		if ( "pending" === $posted["BIL_STATUS"] ) {
			$this->payment_on_hold( $order, sprintf( __( "Payment pending", "woocommerce" )) );
		}
	}
	
	/**
	 * Handle a cancelled payment
	 * @param  WC_Order $order
	 */
	private function payment_status_cancelled( $order, $posted ) {
		$this->payment_status_failed( $order, $posted );
	}
	
	/**
	 * Handle a failed payment
	 * @param  WC_Order $order
	 */
	private function payment_status_failed( $order, $posted ) {
		$order->update_status( "failed", sprintf( __( "Payment %s via Glocash Notify.", "woocommerce" ), wc_clean( $posted["BIL_STATUS"] ) ) );
	}
	
	/**
	 * Handle a refunding order
	 * @param  WC_Order $order
	 */
	private function payment_status_refunding( $order, $posted ) {
		$order->update_status( "processing", sprintf( __( "Payment %s via Glocash Notify.", "woocommerce" ), strtolower( $posted["BIL_STATUS"] ) ) );
	
		$this->send_email_notification(
				sprintf( __( "Payment for order #%s refunding", "woocommerce" ), $order->get_order_number() ),
				sprintf( __( "Order %s has been marked as processing due to a refunding", "woocommerce" ), $order->get_order_number())
		);
	}

	/**
	 * Handle a refunded order
	 * @param  WC_Order $order
	 */
	private function payment_status_refunded( $order, $posted ) {
		$order->update_status( "refunded", sprintf( __( "Payment %s via Glocash Notify.", "woocommerce" ), strtolower( $posted["BIL_STATUS"] ) ) );

		$this->send_email_notification(
			sprintf( __( "Payment for order #%s refunded", "woocommerce" ), $order->get_order_number() ),
			sprintf( __( "Order %s has been marked as refunded", "woocommerce" ), $order->get_order_number())
		);
	}
	
	/**
	 * Handle a complaint order
	 * @param  WC_Order $order
	 */
	private function payment_status_complaint( $order, $posted ) {
		$order->update_status( "processing", sprintf( __( "Payment %s via Glocash Notify.", "woocommerce" ), strtolower( $posted["BIL_STATUS"] ) ) );
	
		$this->send_email_notification(
			sprintf( __( "Payment for order #%s complaint", "woocommerce" ), $order->get_order_number() ),
			sprintf( __( "Order %s has been marked processing due to a complaint", "woocommerce" ), $order->get_order_number())
		);
	}

	/**
	 * Handle a chargeback
	 * @param  WC_Order $order
	 */
	private function payment_status_chargeback( $order, $posted ) {
		$order->update_status( "on-hold", sprintf( __( "Payment %s via Glocash Notify.", "woocommerce" ), wc_clean( $posted["BIL_STATUS"] ) ) );

		$this->send_email_notification(
			sprintf( __( "Payment for order #%s reversed", "woocommerce" ), $order->get_order_number() ),
			sprintf( __( "Order %s has been marked on-hold due to a chargeback", "woocommerce" ), $order->get_order_number() )
		);
	}

	/**
	 * Send a notification to the user handling orders.
	 * @param  string $subject
	 * @param  string $message
	 */
	private function send_email_notification( $subject, $message ) {
		$new_order_settings = get_option( "woocommerce_new_order_settings", array() );
		$mailer             = WC()->mailer();
		$message            = $mailer->wrap_message( $subject, $message );

		$mailer->send( ! empty( $new_order_settings["recipient"] ) ? $new_order_settings["recipient"] : get_option( "admin_email" ), $subject, $message );
	}
}
?>
