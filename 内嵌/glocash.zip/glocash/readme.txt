 === Glocash Pay Plugin for Woocommerce ===
Contributors: Glocash Pay
Tags: payment
Requires at least: 4.0
Tested up to: 6.0
Requires PHP: 7.0
Stable tag: 1.0.9
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Official Glocash module for WordPress WooCommerce.

== Description ==
With years of experience in the payment industry,Glocash has a globally integrated compliance and risk management system, aiming to provide cross-border merchants with safe, compliant, efficient ,convenient, and low-cost cross-border collection, global payment, and foreign exchange services.

== Payment method ==
* Credit/Debit Card

== How to contact us ==
* Official website: <https://www.glocash.com/>
* Technical support team: <support@glocash.com>

== Installation ==

1. Log in to Wordpress administration, click on the `Plugins` tab.
2. Find `WooCommerce Glocash` in the plugin overview and activate it.
3. Go to WooCommerce -> Settings -> Checkout -> Glocash, or you just click `Settings` under `WooCommerce Glocash` plugin.
4. Fill in your `Email` and `Secret Key`, which you can find after logging at your Glocash account. Click `Save changes`.
5. Activate the alternative payment methods you want to use. Please note the `Status` of `Glocash` payment method is disabled in order to prevent it to show as a payment option.

== Changelog ==

= 1.0.0 =
Initial stable release

